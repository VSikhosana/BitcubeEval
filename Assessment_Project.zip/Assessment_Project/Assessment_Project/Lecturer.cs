﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_Project
{

    interface ILecture
    {

    }
   public class Lecturer:IDegree
    {
        public string LName { get; set; }
        public string LSurname { get; set; }

        public string LEmailAdress { get; set; }

        public DateTime LDOB { get; set; }
        public string DegreeName { get; set; }
        public string Duration { get; set; }





        // link to a degree

        public Lecturer(string lname,string lsurname, string lemail, DateTime ldob)


        {
            this.LName = lname;
            this.LSurname = lsurname;
            this.LEmailAdress = lemail;
            this.LDOB = ldob;
            
        }

        public Lecturer()
        {
        }
    }
}
