﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_Project
{


    interface IDegree
    {
        
    }

    public class Degree:ICourse,ILecture


    {

        public string DegreeName { get; set; }
        public string Duration { get; set; }
        public string CourseDuration { get; internal set; }
        public string CourseName { get; internal set; }
        public string LName { get; set; }
        public string LSurname { get; set; }

        public string LEmailAdress { get; set; }

        public DateTime LDOB { get; set; }


        //public string CourseName { get; set; }
        //public string CourseDuration { get; set; }



        public Degree(string degreeName, string duration, string coursename, string courseduration)

        {
            this.DegreeName = degreeName;
            this.Duration = duration;
            ////this.CourseDuration = courseduration;
            ////this.CourseName = coursename;

        }
        public Degree()

        {

        }

       

    }
}


  