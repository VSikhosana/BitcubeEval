﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_Project
{
   public class Student:Degree
    {
        //private static int StudentID;
        public string Name { get; set; }
        public string Surname { get; set; }

        public string EmailAddress { get; set; }
        public DateTime dateOfBirth { get; set; }

        

        public Student(string name, string surname, string email, DateTime dob)
        {
            this.Name = name;
            this.Surname = surname;
            this.EmailAddress = email;
            this.dateOfBirth = dob;
           


         }

        public Student()
        {
        }
    }

  

}
