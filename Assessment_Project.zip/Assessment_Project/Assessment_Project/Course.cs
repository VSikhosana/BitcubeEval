﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_Project
{


    interface ICourse
    {

    }
    public class Course: IDegree
    {
        public string CourseName { set; get; }
        public string CourseDuration { get; set; }

        public string DegreeName { get; set; }
        public string Duration { get; set; }




       

        public Course()
        {
        }
    }
}


