﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_Project
{
    class Program
    {
        static void Main(string[] args)
        {
            //Student information
            Student student1 = new Student("Veronica", "Phiri", "phiri@gmail.com", Convert.ToDateTime("05/05/1984"));
            student1.DegreeName = "BSc Computer Engineering";
            student1.Duration = "4 years";

            //Print student details
            Console.WriteLine("<Student Info> \nFirst name:{0}\nFull Name:{0} {1} \nEmail Address: {2}\nDate of birth :{3} \nDegree enrolled: {4} \nDegree Duration:{5}", student1.Name, student1.Surname, student1.EmailAddress, student1.dateOfBirth, student1.DegreeName, student1.Duration);

            /// Lectures and their respective Degrees
            Lecturer lecturer1 = new Lecturer()
            {
                LName = "Pearl",
                LSurname = "Zulu",
                LEmailAdress = "PZ@Learning",
                LDOB = Convert.ToDateTime("07/06/1985"),
                DegreeName = "Bsc Civil Engineering",
                Duration = "4 years"

            };
            Lecturer lecturer2 = new Lecturer()
            {
                LName = "Tom",
                LSurname = "Hanks",
                LEmailAdress = "TH@Learning",
                LDOB = Convert.ToDateTime("07/06/1985"),
                DegreeName = "Bsc Computer Engineering",
                Duration = "4 years"

            };
            List<Lecturer> allLectures = new List<Lecturer>();
            allLectures.Add(lecturer1);
            allLectures.Add(lecturer2);

            //Print Lecturer's info
            Console.WriteLine("\n***Here is a list of available lacture***");
            foreach(Lecturer l in allLectures)
            {
                Console.WriteLine("\nFirst name:{0}\nFull name:{0} {1}\nEmail address:{2}\nDate of birth:{3}\nDegree name:{4}\nDuration:{5}",l.LName,l.LSurname,l.LEmailAdress,l.LDOB,l.DegreeName,l.Duration);
            }

            //Degree with responsible lectures

                Degree degree1 = new Degree()
            {
                LName = "Tom",
                LSurname = "Hanks",
                DegreeName = "Bsc Computer Engineering",
                Duration = "4 years",
                CourseName = "Programming in C#",
                CourseDuration = "6 months"
            };

            Degree degree2 = new Degree()

            {
                LName = "Tom",
                LSurname = "Hanks",
                DegreeName = "Bsc Computer Engineering",
                Duration = "4 years",
                CourseName = "Informatics II",
                CourseDuration = "6 months"
            };
            Degree degree3 = new Degree()

            {
                LName = "Pearl ",
                LSurname = "Zulu",
                DegreeName = "Bsc Civil Engineering",
                Duration = "4 years",
                CourseName = "Business Management",
                CourseDuration = "4 months"
            };

            List<Degree> allDegrees = new List<Degree>();
            allDegrees.Add(degree1);
            allDegrees.Add(degree2);
            allDegrees.Add(degree3);


            Console.WriteLine("\n****Here are available degrees and its respective courses***");
            foreach (Degree d in allDegrees)
            {
                Console.WriteLine("\nDegree name:{0}\nDegree duration: {1}\nCourse name:{2} Course duration:{3}\nResponsible lecture:{4} {5}",d.DegreeName,d.Duration, d.CourseName,d.CourseDuration,d.LName, d.LSurname);
            }

            //Course available with corresponding degree
            Course course1 = new Course()
                {
                   
                   DegreeName ="Bsc Computer Science" ,
                   CourseName = "Programming in C#", 
                   CourseDuration = "6 months"
                };
        Course course2 = new Course()
        {
                   DegreeName = "Bsc Civil Engineering",
                    CourseName = "Business Management",
                    CourseDuration = "4 months"
                };
          Course course3 = new Course()
            {
              DegreeName = "Bsc Computer Science",
              CourseName = "Business Management",
              CourseDuration = "4 months"
          };

            List<Course> allCourses = new List<Course>(2);
                allCourses.Add(course1);
                allCourses.Add(course2);


            Console.WriteLine("\n***Courses available with corresponding degrees***");
            foreach (Course c in allCourses)
            {
                Console.WriteLine("\nDegree Name:{0}\nCourse Name:{1}\nCourse Duration:{2}", c.DegreeName, c.CourseName,c.CourseDuration);

            }

            Console.ReadKey();


















        }
    }
}
